    <div <?php echo e($attributes->class(["badge"])); ?>>
        <?php echo e($value); ?>

    </div><?php /**PATH C:\qb\qbweb\ClearFlow\storage\framework\views/e68abdaa1a0284aa8312a535cfa4ec31.blade.php ENDPATH**/ ?>